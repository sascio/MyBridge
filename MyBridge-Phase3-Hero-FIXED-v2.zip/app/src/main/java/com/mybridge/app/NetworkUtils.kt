package com.mybridge.app

import java.net.Inet4Address
import java.net.NetworkInterface

object NetworkUtils {
    fun getLanIpv4(): String? {
        return try {
            NetworkInterface.getNetworkInterfaces()?.toList()
                ?.asSequence()
                ?.filter { it.isUp && !it.isLoopback && !it.isVirtual }
                ?.flatMap { it.inetAddresses.toList().asSequence() }
                ?.filterIsInstance<Inet4Address>()
                ?.map { it.hostAddress }
                ?.firstOrNull { ip ->
                    ip.startsWith("192.168.") ||
                    ip.startsWith("10.") ||
                    ip.matches(Regex("""172\.(1[6-9]|2\d|3[0-1])\..*"""))
                }
        } catch (_: Exception) {
            null
        }
    }
}
