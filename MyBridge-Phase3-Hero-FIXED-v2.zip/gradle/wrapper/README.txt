Use Android Studio's Gradle sync, or generate the wrapper with a local Gradle installation.
