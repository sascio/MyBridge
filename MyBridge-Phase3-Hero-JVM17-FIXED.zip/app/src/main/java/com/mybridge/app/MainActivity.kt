package com.mybridge.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

private val Bg = Color(0xFF050506)
private val Surface = Color(0xFF111113)
private val Surface2 = Color(0xFF17171A)
private val Purple = Color(0xFF8B4DFF)
private val Purple2 = Color(0xFFB48CFF)
private val Green = Color(0xFF45E88A)
private val Muted = Color(0xFF85848E)

class MainActivity : ComponentActivity() {
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch("android.permission.POST_NOTIFICATIONS")

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg,
                    surface = Surface,
                    primary = Purple,
                    secondary = Purple2
                )
            ) {
                MyBridgeApp()
            }
        }
    }

    private fun startBridge() {
        val i = Intent(this, BridgeService::class.java).setAction(BridgeService.ACTION_START)
        ContextCompat.startForegroundService(this, i)
    }

    private fun stopBridge() {
        startService(Intent(this, BridgeService::class.java).setAction(BridgeService.ACTION_STOP))
    }

    private fun copy(text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("MyBridge URL", text))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun installStremio(url: String) {
        try {
            val deepLink = url.replaceFirst(Regex("^https?://"), "stremio://")
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(deepLink)))
        } catch (_: Exception) {
            copy(url)
            Toast.makeText(this, "Stremio not found. Manifest URL copied.", Toast.LENGTH_LONG).show()
        }
    }

    @Composable
    private fun MyBridgeApp() {
        var tab by remember { mutableIntStateOf(0) }
        val running = remember { mutableStateOf(BridgeService.isRunning) }
        val lanIp = remember { mutableStateOf(NetworkUtils.getLanIpv4()) }

        LaunchedEffect(Unit) {
            while (true) {
                running.value = BridgeService.isRunning
                lanIp.value = NetworkUtils.getLanIpv4()
                delay(1500)
            }
        }

        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B0B0D), tonalElevation = 0.dp) {
                    val labels = listOf("Server", "Extensions", "Logs", "Settings")
                    val icons = listOf(Icons.Default.PlayArrow, Icons.Default.Extension, Icons.Default.List, Icons.Default.Settings)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = {
                                Box(
                                    Modifier.clip(RoundedCornerShape(18.dp))
                                        .background(if (tab == i) Color(0xFF251447) else Color.Transparent)
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) { Icon(icons[i], null) }
                            },
                            label = { Text(label, fontSize = 12.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Purple2,
                                selectedTextColor = Purple2,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted,
                                indicatorColor = Color.Transparent
                            )
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> ServerScreen(running.value, lanIp.value)
                    1 -> ExtensionsScreen()
                    2 -> LogsScreen()
                    3 -> SettingsScreen()
                }
            }
        }
    }

    @Composable
    private fun AppHeader(title: String, subtitle: String? = null, action: @Composable (() -> Unit)? = null) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                if (subtitle != null) Text(subtitle, color = Muted, fontSize = 14.sp)
            }
            action?.invoke()
        }
    }

    @Composable
    private fun ServerScreen(running: Boolean, ip: String?) {
        var showQr by remember { mutableStateOf(false) }
        var mode by remember { mutableIntStateOf(0) }

        val localUrl = "http://127.0.0.1:${BridgeService.PORT}/manifest.json"
        val lanUrl = if (ip != null) "http://$ip:${BridgeService.PORT}/manifest.json" else null
        val selectedUrl = lanUrl ?: localUrl

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            item {
                AppHeader(
                    title = "MyBridge",
                    subtitle = "STREMIO BRIDGE"
                )
            }

            item {
                HeroLogo()
                Spacer(Modifier.height(14.dp))
            }

            item {
                Card(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Surface),
                    shape = RoundedCornerShape(28.dp)
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(12.dp).clip(CircleShape).background(if (running) Green else Color(0xFF6E6E76)))
                            Spacer(Modifier.width(10.dp))
                            Text(
                                if (running) "Running" else "Stopped",
                                color = if (running) Green else Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("• Port ${BridgeService.PORT}", color = Muted)
                        }

                        Spacer(Modifier.height(18.dp))

                        Button(
                            onClick = { if (running) stopBridge() else startBridge() },
                            modifier = Modifier.fillMaxWidth().height(60.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (running) Color(0xFF9B2626) else Purple
                            ),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(if (running) Icons.Default.Stop else Icons.Default.PlayArrow, null)
                            Spacer(Modifier.width(10.dp))
                            Text(if (running) "Stop Server" else "Start Server", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(Modifier.height(18.dp))
                        HorizontalDivider(color = Color(0xFF29292D))
                        Spacer(Modifier.height(16.dp))

                        Row(Modifier.fillMaxWidth()) {
                            ModeTab("Nuvio", mode == 0) { mode = 0 }
                            ModeTab("Stremio", mode == 1) { mode = 1 }
                        }

                        Spacer(Modifier.height(20.dp))
                        Text("CONNECTION URLS", color = Muted, letterSpacing = 1.5.sp, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))

                        UrlCard(
                            label = "LAN HTTP",
                            url = selectedUrl,
                            enabled = running && lanUrl != null,
                            onCopy = { copy(selectedUrl) }
                        )

                        Spacer(Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { showQr = true },
                                enabled = running,
                                modifier = Modifier.weight(1f).height(52.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(Icons.Default.QrCode2, null)
                                Spacer(Modifier.width(7.dp))
                                Text("QR Code")
                            }

                            Button(
                                onClick = { installStremio(selectedUrl) },
                                enabled = running,
                                modifier = Modifier.weight(1f).height(52.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(Icons.Default.OpenInNew, null)
                                Spacer(Modifier.width(7.dp))
                                Text("Install")
                            }
                        }

                        Spacer(Modifier.height(12.dp))
                        Text(
                            if (lanUrl != null) "● LAN ready • Same Wi‑Fi devices can connect"
                            else "○ Connect to Wi‑Fi to enable LAN access",
                            color = if (lanUrl != null) Green else Muted,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(16.dp)) }

            item {
                Card(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Surface2),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, null, tint = Purple2)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Local-first bridge", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text("Your phone hosts the addon endpoint.", color = Muted, fontSize = 13.sp)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("No cloud tunnel is enabled in this build.", color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }

        if (showQr) {
            QrDialog(selectedUrl) { showQr = false }
        }
    }

    @Composable
    private fun HeroLogo() {
        Box(
            Modifier.fillMaxWidth().height(145.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.size(105.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFF8B2BFF), Color(0xFF151018))))
            )
            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(62.dp))
        }
    }

    @Composable
    private fun ModeTab(text: String, selected: Boolean, onClick: () -> Unit) {
        Column(
            Modifier.weight(1f).clickable { onClick() }.padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text, color = if (selected) Purple2 else Muted, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(3.dp).background(if (selected) Purple2 else Color.Transparent))
        }
    }

    @Composable
    private fun UrlCard(label: String, url: String, enabled: Boolean, onCopy: () -> Unit) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF151518))
                .border(1.dp, Color(0xFF29292E), RoundedCornerShape(18.dp))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF2A1358)).padding(horizontal = 10.dp, vertical = 10.dp)
            ) { Text(label, color = Purple2, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp))
            Text(url, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
            IconButton(onClick = onCopy, enabled = enabled) { Icon(Icons.Default.ContentCopy, null, tint = if (enabled) Purple2 else Muted) }
        }
    }

    @Composable
    private fun QrDialog(url: String, close: () -> Unit) {
        val bitmap = remember(url) { QrGenerator.generate(url, 600) }
        AlertDialog(
            onDismissRequest = close,
            containerColor = Surface,
            title = { Text("Scan to connect", fontWeight = FontWeight.Bold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(260.dp).background(Color.White).padding(10.dp)) {
                        androidx.compose.foundation.Image(bitmap.asImageBitmap(), null, Modifier.fillMaxSize())
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(url, color = Muted, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { copy(url); close() }) { Text("Copy URL") }
            },
            dismissButton = { TextButton(onClick = close) { Text("Close") } }
        )
    }

    @Composable
    private fun ExtensionsScreen() {
        var query by remember { mutableStateOf("") }
        val items = listOf(
            Extension("Cinemeta Adapter", "Metadata", true, "v1.0"),
            Extension("Demo Movies", "Movies", true, "v0.3"),
            Extension("Demo Series", "Series", true, "v0.3"),
            Extension("Cloudstream Runtime", "Runtime", false, "Coming soon")
        ).filter { it.name.contains(query, true) }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
            item {
                AppHeader(
                    "Extensions",
                    "${items.count { it.installed }} installed • runtime-ready architecture",
                    action = {
                        IconButton(onClick = {}) {
                            Icon(Icons.Default.Refresh, null, tint = Purple2)
                        }
                    }
                )
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    placeholder = { Text("Search extensions...", color = Muted) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = Color(0xFF29292E)
                    )
                )
                Spacer(Modifier.height(16.dp))
            }
            items(items) { ext ->
                ExtensionCard(ext)
            }
        }
    }

    data class Extension(val name: String, val category: String, val installed: Boolean, val version: String)

    @Composable
    private fun ExtensionCard(ext: Extension) {
        Card(
            Modifier.padding(horizontal = 18.dp, vertical = 6.dp).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Surface),
            shape = RoundedCornerShape(22.dp)
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(56.dp).clip(RoundedCornerShape(16.dp))
                        .background(Brush.linearGradient(listOf(Purple, Color(0xFF4B1A9B)))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Extension, null, tint = Color.White, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(ext.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(ext.category, color = Muted, fontSize = 13.sp)
                    Text(ext.version, color = Purple2, fontSize = 12.sp)
                }
                if (ext.installed) {
                    Surface(color = Color(0xFF123B25), shape = RoundedCornerShape(10.dp)) {
                        Text("INSTALLED", Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    OutlinedButton(onClick = {}, shape = RoundedCornerShape(12.dp)) { Text("Add") }
                }
            }
        }
    }

    @Composable
    private fun LogsScreen() {
        val logs = listOf(
            "Server started on 0.0.0.0:8080",
            "LAN endpoint detected",
            "GET /manifest.json 200",
            "GET /catalog/movie/demo_movies.json 200",
            "GET /meta/movie/tt1254207.json 200",
            "GET /stream/movie/tt1254207.json 200",
            "GET /meta/series/mybridge:demo-series.json 200"
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 30.dp)) {
            item {
                AppHeader(
                    "Logs",
                    "${logs.size} recent entries",
                    action = {
                        IconButton(onClick = {}) { Icon(Icons.Default.DeleteSweep, null, tint = Color(0xFFFF7070)) }
                    }
                )
            }
            items(logs) { line ->
                Card(
                    Modifier.padding(horizontal = 18.dp, vertical = 4.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0E0E10)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Green))
                        Spacer(Modifier.width(12.dp))
                        Text(line, color = Color(0xFFB9B5C9), fontSize = 12.sp)
                    }
                }
            }
        }
    }

    @Composable
    private fun SettingsScreen() {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 30.dp)) {
            item { AppHeader("Settings", "MyBridge configuration") }
            item {
                SettingGroup("Server") {
                    SettingRow(Icons.Default.Router, "Port", "8080")
                    SettingRow(Icons.Default.Wifi, "LAN access", "Automatic")
                    SettingRow(Icons.Default.Code, "Protocol", "Stremio Addon API")
                }
            }
            item {
                SettingGroup("About") {
                    SettingRow(Icons.Default.Info, "Version", "0.3.0")
                    SettingRow(Icons.Default.Verified, "Architecture", "Clean-room implementation")
                }
            }
        }
    }

    @Composable
    private fun SettingGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text(title.uppercase(), color = Muted, fontSize = 11.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold, Modifier.padding(6.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(content = content)
            }
        }
    }

    @Composable
    private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Purple2)
            Spacer(Modifier.width(14.dp))
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text(value, color = Muted, fontSize = 13.sp)
        }
    }
}
