package com.mybridge.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.call
import io.ktor.server.cio.CIO
import io.ktor.server.engine.ApplicationEngine
import io.ktor.server.engine.embeddedServer
import io.ktor.server.response.header
import io.ktor.server.response.respondText
import io.ktor.server.routing.get
import io.ktor.server.routing.routing
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

class BridgeService : Service() {
    private var server: ApplicationEngine? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startBridge()
            ACTION_STOP -> stopBridge()
        }
        return START_NOT_STICKY
    }

    private fun startBridge() {
        if (server != null) return
        startForeground(NOTIFICATION_ID, notification())

        server = embeddedServer(CIO, host = "0.0.0.0", port = PORT) {
            routing {
                get("/") { call.respondStremio("""{"name":"MyBridge","version":"0.3.0","status":"ok"}""") }
                get("/health") { call.respondStremio("""{"status":"ok","server":"MyBridge","version":"0.3.0"}""") }
                get("/manifest.json") { call.respondStremio(MANIFEST_JSON) }

                get("/catalog/{type}/{catalogId}.json") {
                    respondCatalog(call.parameters["type"], call.parameters["catalogId"], "")
                }

                get("/catalog/{type}/{catalogId}/{extra}.json") {
                    val extra = URLDecoder.decode(
                        call.parameters["extra"] ?: "",
                        StandardCharsets.UTF_8
                    )
                    respondCatalog(call.parameters["type"], call.parameters["catalogId"], extra)
                }

                get("/meta/{type}/{id}.json") {
                    respondMeta(call.parameters["type"], call.parameters["id"])
                }

                get("/stream/{type}/{id}.json") {
                    respondStream(call.parameters["type"], call.parameters["id"])
                }
            }
        }.start(wait = false)

        isRunning = true
    }

    private suspend fun respondCatalog(type: String?, id: String?, extra: String) {
        when {
            type == "movie" && id == MOVIE_CATALOG -> {
                val search = extra.substringAfter("search=", "").substringBefore("&").lowercase()
                if (search.isBlank() || "bunny".contains(search) || "big".contains(search)) {
                    callRespond(CATALOG_MOVIES)
                } else {
                    callRespond("""{"metas":[]}""")
                }
            }
            type == "series" && id == SERIES_CATALOG -> callRespond(CATALOG_SERIES)
            else -> callRespond("""{"metas":[]}""")
        }
    }

    private suspend fun respondMeta(type: String?, id: String?) {
        when {
            type == "movie" && id == MOVIE_ID -> callRespond(MOVIE_META)
            type == "series" && id == SERIES_ID -> callRespond(SERIES_META)
            else -> callRespond("""{"meta":null}""")
        }
    }

    private suspend fun respondStream(type: String?, id: String?) {
        when {
            type == "movie" && id == MOVIE_ID -> callRespond(MOVIE_STREAM)
            type == "series" && id?.startsWith("$SERIES_ID:") == true -> callRespond(SERIES_STREAM)
            else -> callRespond("""{"streams":[]}""")
        }
    }

    private suspend fun io.ktor.server.application.ApplicationCall.callRespond(json: String) {
        response.header(HttpHeaders.AccessControlAllowOrigin, "*")
        response.header(HttpHeaders.CacheControl, "no-store")
        respondText(json, ContentType.Application.Json, HttpStatusCode.OK)
    }

    private suspend fun io.ktor.server.application.ApplicationCall.respondStremio(json: String) =
        callRespond(json)

    private fun stopBridge() {
        server?.stop(500, 1000)
        server = null
        isRunning = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MyBridge")
            .setContentText("Bridge active • port $PORT")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build()

    private fun createNotificationChannel() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "MyBridge Server",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
    }

    override fun onDestroy() {
        server?.stop(500, 1000)
        server = null
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.mybridge.action.START"
        const val ACTION_STOP = "com.mybridge.action.STOP"
        const val PORT = 8080
        const val CHANNEL_ID = "mybridge_server"
        const val NOTIFICATION_ID = 1001

        const val MOVIE_CATALOG = "demo_movies"
        const val SERIES_CATALOG = "demo_series"
        const val MOVIE_ID = "tt1254207"
        const val SERIES_ID = "mybridge:demo-series"

        val MANIFEST_JSON = """
        {
          "id":"com.mybridge.bridge",
          "version":"0.3.0",
          "name":"MyBridge",
          "description":"A local Stremio-compatible bridge for extensions.",
          "logo":"https://www.stremio.com/website/stremio-logo-small.png",
          "resources":[
            "catalog",
            {"name":"meta","types":["movie","series"],"idPrefixes":["tt","mybridge:"]},
            {"name":"stream","types":["movie","series"],"idPrefixes":["tt","mybridge:"]}
          ],
          "types":["movie","series"],
          "catalogs":[
            {"type":"movie","id":"demo_movies","name":"MyBridge Movies","extra":[{"name":"search","isRequired":false}]},
            {"type":"series","id":"demo_series","name":"MyBridge Series","extra":[{"name":"search","isRequired":false}]}
          ],
          "idPrefixes":["tt","mybridge:"]
        }
        """.trimIndent()

        val CATALOG_MOVIES = """
        {"metas":[
          {"id":"$MOVIE_ID","type":"movie","name":"Big Buck Bunny","releaseInfo":"2008",
           "poster":"https://image.tmdb.org/t/p/w600_and_h900_bestv2/uVEFQvFMMsg4e6yb03xOfVsDz4o.jpg",
           "posterShape":"poster"}
        ]}
        """.trimIndent()

        val CATALOG_SERIES = """
        {"metas":[
          {"id":"$SERIES_ID","type":"series","name":"MyBridge Showcase","releaseInfo":"2026-",
           "poster":"https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=600&q=80",
           "posterShape":"poster"}
        ]}
        """.trimIndent()

        val MOVIE_META = """
        {"meta":{
          "id":"$MOVIE_ID","type":"movie","name":"Big Buck Bunny","releaseInfo":"2008",
          "description":"A short animated film used as the public-domain demo for testing the MyBridge Stremio protocol.",
          "poster":"https://image.tmdb.org/t/p/w600_and_h900_bestv2/uVEFQvFMMsg4e6yb03xOfVsDz4o.jpg",
          "posterShape":"poster","runtime":"00:09:56","genres":["Animation","Comedy"]
        }}
        """.trimIndent()

        val SERIES_META = """
        {"meta":{
          "id":"$SERIES_ID","type":"series","name":"MyBridge Showcase","releaseInfo":"2026-",
          "description":"A two-episode protocol demonstration series for MyBridge.",
          "poster":"https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=600&q=80",
          "posterShape":"poster",
          "videos":[
            {"id":"$SERIES_ID:1:1","title":"Getting Started","released":"2026-01-01T00:00:00.000Z","season":1,"episode":1,"available":true},
            {"id":"$SERIES_ID:1:2","title":"The Bridge","released":"2026-01-02T00:00:00.000Z","season":1,"episode":2,"available":true}
          ]
        }}
        """.trimIndent()

        val MOVIE_STREAM = """
        {"streams":[
          {"name":"Demo • 1080p","title":"Big Buck Bunny","quality":"1080p",
           "url":"https://storage.googleapis.com/coverr-main/mp4/Mt_Baker.mp4"}
        ]}
        """.trimIndent()

        val SERIES_STREAM = """
        {"streams":[
          {"name":"MyBridge Demo • MP4","title":"Episode stream",
           "url":"https://storage.googleapis.com/coverr-main/mp4/Mt_Baker.mp4",
           "behaviorHints":{"bingeGroup":"mybridge-demo"}}
        ]}
        """.trimIndent()

        @Volatile var isRunning = false
    }
}
