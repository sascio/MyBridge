# MyBridge — Phase 3 Hero UI

Phase 3 adds a polished, dark, purple-accented Android UI inspired by the *interaction patterns* visible in the provided reference screenshots, without copying CNCVerse branding/assets.

## Included

### Server
- Hero-style server dashboard
- Start/stop foreground server
- Automatic LAN IPv4 detection
- Localhost + LAN manifest URL
- Copy URL
- QR code generation
- "Install in Stremio" button using the `stremio://` deep-link scheme
- Nuvio/Stremio mode tabs
- Connection status

### Extensions
- Searchable extension cards
- Installed/available state
- Architecture-ready extension list

### Logs
- Request/status log UI
- Clear-log control placeholder

### Settings
- Server and protocol information
- Version/about information

### Stremio protocol
- `/manifest.json`
- Movie catalog + search
- Series catalog + search
- Movie metadata
- Series metadata with episode `videos`
- Movie streams
- Series episode streams (`seriesId:season:episode`)

The Stremio protocol defines catalogs, metadata and streams as `/catalog/...`, `/meta/...` and `/stream/...` HTTP resources and supports `stremio://` deep links for addon manifests.

## Build

Open the project in Android Studio, sync Gradle and run the `app` configuration.

```bash
./gradlew assembleDebug
```

The debug APK will be generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Network

When the phone is on Wi-Fi, MyBridge detects a private IPv4 address such as:

```text
http://192.168.1.50:8080/manifest.json
```

The Stremio-compatible client must be able to reach the phone over the LAN.

For the Android phone itself, `127.0.0.1` can be used.

## Important

This build does NOT implement Cloudflare tunnels or arbitrary Cloudstream plugin execution. Those are separate engineering tasks. The extension cards are UI/architecture placeholders until a properly licensed extension runtime is implemented.
